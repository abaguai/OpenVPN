<?php
return array(
	'默认'=>'style/images/main/bg.jpg',
	'水杯'=>'style/images/main/beizi.jpg',
	'河流'=>'style/images/main/heliu.jpg',
	'蓝天'=>'style/images/main/lantian.jpg',
	'萌萌哒'=>'style/images/main/meng.jpg',
	'沙漠'=>'style/images/main/shamo.jpg',
	'山水'=>'style/images/main/shanshui.jpg',
	'设计'=>'style/images/main/shejishi.jpg',
	'手指相依'=>'style/images/main/shouzhi.jpg',
	'唯美'=>'style/images/main/weimei.jpg',
	'心'=>'style/images/main/xin.jpg',
	'星空'=>'style/images/main/xingkong.jpg',
	'夜市'=>'style/images/main/yeshi.jpg',
	'照片'=>'style/images/main/zhaop.jpg'
);