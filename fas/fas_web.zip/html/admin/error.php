<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<title>FAS后台管理登录验证</title>
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Nova+Flat' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" /></head><body>
<div class="container"> 
<div class="row pad-top text-center">
<div class="col-md-6 col-md-offset-3 text-center">
<h1> 管理后台面板已被关闭！ </h1>
<h5> 如您不是管理员，请自行离开！</h5> 
<span id="error-link"></span>
<h2>禁止访问！</h2></div></div>
<div class="row text-center">
<div class="col-md-8 col-md-offset-2">
<h3> <i  class="fa fa-lightbulb-o fa-5x"></i> </h3>
<a href="../user/" class="btn btn-primary">返回个人中心</a><br/><br/>
<br/>Copyright © 2016-2018 <a href="https://yyrh.me/" target="_blank" title="yyrh.me">烟雨如花</a> All rights reserved.</a></div></div></div>
<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/countUp.js"></script>
<script src="js/custom.js"></script>
</body>